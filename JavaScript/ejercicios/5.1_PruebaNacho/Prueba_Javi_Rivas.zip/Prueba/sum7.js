/*
  Escribe una función que tome un array de numeros enteros de mas de 3 elementos
  y retorne true si 3 elementos consecutivos suman 7
 */

function sumSeven(arr) {
  let sum = 0;
  for (i = 0; i < arr.length; i++) {
    //compruebo la suma de tres indices seguidos
    sum = arr[i] + arr[i + 1] + arr[i + 2]
    //si la suma es 7 la variable de control la llevo mas alla del limite para que el bucle no de mas vueltas
    //y retorno True
    if (sum === 7) {
      i = arr.length;
      return true;
    }

  }
}
//muestro por pantalla el retorno de la funciónn para un array concreto
console.log(sumSeven([2, 1, 5, 1, 0]));

//NOTA: No se como hacer para que retorne false cuando nmo se cumpla que tres elementos 
//seguidos sumen 7

