/*
Ejecutando el codigo siguiente,
se supone que devuelve solamente los numeros impares.
*/

(function () {
  let values = [3, 8, "15", Number.MAX_VALUE, Infinity, -23],
    oddValues = [],
    lenValues = values.length,
    isOdd = function (value) {
      return value % 2 !== 0; //retorna el nº impar
    };

  while (lenValues--) {
    if (isOdd(values[lenValues])) {
      oddValues.push(values[lenValues]);
    }
  }
  console.log(oddValues);
})();

/* Sin embargo cuando lo ejecutamos nos devuelve  [-23, Infinity, "15", 3].

- Por que Number.MAX_VALUE no se ha incluido en la respuesta?
// porque  no puede calcular si el modulo de infinito es impar o par

- Modificar el codigo para que Infinity no se incluya en la respuesta */
