/*
Escribe un método que, introduciendole un número N que representa dónde
se encuentra actualmente el
minutero en un reloj, devuelva el ángulo
formado por el minutero y la marca de las 12 en punto en el reloj.
*/

function simpleClockAngle(num) {}

simpleClockAngle(15);
